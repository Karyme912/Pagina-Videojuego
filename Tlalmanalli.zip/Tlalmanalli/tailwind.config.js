/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.{html,js,json}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

